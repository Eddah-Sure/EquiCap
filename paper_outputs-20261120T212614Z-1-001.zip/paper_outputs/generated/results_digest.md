# Results digest

- `HthreeComp` = 0.999
- `HthreeStruct` = 0.88--0.93
- `MeffStruct` = 6.4--7.3
- `bestComp` = Composition-only/capsule
- `bestStruct` = CGCNN-style/capsule
- `biasMax` = 2.6
- `capMax` = 0.078
- `compCapsGain` = $-4.9$
- `compReadoutSpread` = 7.9
- `dgeomCI` = $[4.0, 5.4]$
- `dgeomPct` = 13.9
- `dgeomVal` = 4.7
- `fixedMaxFp` = $3.3\times10^{-5}$
- `fixedMaxSixtyFour` = $3.1\times10^{-14}$
- `fracTail` = 2.9--7.3
- `gpuName` = Tesla T4
- `graphMs` = 17.0
- `kurtRange` = 17.7--87.9
- `madRange` = 20.5--29.4
- `maeBestComp` = 33.9
- `maeBestStruct` = 29.2
- `memRatio` = 2.6
- `nAudited` = 640
- `nSeedsMain` = 1
- `painnGap` = 6.3--8.5
- `paramRatio` = 2.1
- `pninetynineRatio` = 4.2--5.7
- `rTwoMin` = 0.9961
- `rebuiltFracGt` = 0.00
- `rebuiltMax` = $3.4\times10^{-5}$
- `rebuiltMaxSixtyFour` = $3.3\times10^{-14}$
- `staleRange` = 0.00--1.83
- `timeRatio` = 2.7

## Notes

- data_report/split_summary.csv missing: run EQUICAP.run_split_report()
- ANOVA needs at least two seeds in every grid cell
- fe_cgcnn_capsule_base_s0: audit has no fp64-cap4 regime (written before 2.0.1); re-audit or retrain it
- structures hit by the 4-image cap: mp-1002114 (the manuscript names mp-1002114)
