# Expected results

| group        | check                                                  | expected      | observed                   | status   |
|:-------------|:-------------------------------------------------------|:--------------|:---------------------------|:---------|
| completeness | 3x3 grid                                               | 9 cells       | 9 cells, 1 seeds (minimum) | PASS     |
| completeness | accuracy controls (6)                                  | 6 cells       | 0 cells                    | INFO     |
| completeness | band gap                                               | 7 cells       | 0 seeds (minimum)          | MISSING  |
| data         | split report                                           | present       | absent                     | MISSING  |
| accuracy     | every model beats the mean predictor (MAD/MAE)         | > 10          | min 20.5                   | PASS     |
| direction    | scalar-vector trails distance-only at every readout    | PaiNN > CGCNN | +6.6, +8.5, +6.3           | PASS     |
| accuracy     | structural headroom resolved                           | CI excludes 0 | $[4.0, 5.4]$               | PASS     |
| routing      | H1 = 1 (cgcnn/base)                                    | 1.0000        | 1.0000                     | PASS     |
| routing      | H1 = 1 (painn/base)                                    | 1.0000        | 1.0000                     | PASS     |
| routing      | H1 = 1 (composition/base)                              | 1.0000        | 1.0000                     | PASS     |
| direction    | structural couplings depart from uniform only modestly | H3 > 0.8      | 0.876--0.931               | PASS     |
| direction    | composition-only couplings stay uniform                | H3 > 0.99     | 0.999                      | PASS     |
| controls     | 4-image cap breaks basis-change invariance (fp64)      | > 1e-9        | 7.8e-02 on 1 structure(s)  | PASS     |
| invariance   | fixed edges, float64, all changes                      | < 1e-9        | 3.1e-14                    | PASS     |
| invariance   | rebuilt edges, float64 (complete graph builder)        | < 1e-9        | 3.3e-14                    | PASS     |
| invariance   | rebuilt edges, float32                                 | < 1e-3        | 3.4e-05                    | PASS     |
| invariance   | composition-only, every regime                         | < 1e-6        | 6.0e-07                    | PASS     |
