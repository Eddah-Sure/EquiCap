! data_report/split_summary.csv missing: run `equicap --split-report`

## Main results (formation_energy_per_atom)
        Backbone   Readout  Params  Seeds MAE (meV/atom) 95% CI RMSE (meV/atom)     R2 MAD/MAE Val MAE
     CGCNN-style Attention 265,986      1           29.8     --            42.7 0.9982    28.8    30.1
     CGCNN-style   Capsule 270,625      1           29.2     --            42.0 0.9983    29.4    29.3
     CGCNN-style  Mean/max 266,113      1           31.6     --            45.4 0.9980    27.1    32.3
  PaiNN-inspired Attention 557,442      1           36.4     --            60.8 0.9964    23.6    37.3
  PaiNN-inspired   Capsule 562,097      1           37.7     --            63.6 0.9961    22.7    39.2
  PaiNN-inspired  Mean/max 557,569      1           37.9     --            61.3 0.9964    22.6    38.8
Composition-only Attention  86,402      1           41.8     --            59.3 0.9966    20.5    41.7
Composition-only   Capsule  91,041      1           33.9     --            52.3 0.9974    25.3    34.1
Composition-only  Mean/max  86,529      1           38.9     --            56.3 0.9969    22.1    38.8

## ANOVA (structural, formation_energy_per_atom): needs >= 2 seeds in every cell

## ANOVA (all, formation_energy_per_atom): needs >= 2 seeds in every cell

## Paired contrasts (formation_energy_per_atom)
  family                                                    contrast  Delta (meV/atom)           95% CI  rel. % p (Holm)    d_z p TOST      verdict
headroom Headroom: comp/attention vs best structural (cgcnn/capsule)             12.61 [+11.86, +13.35]    30.2 4.3e-226  0.350     --     B better
headroom   Headroom: comp/capsule vs best structural (cgcnn/capsule)              4.71   [+4.00, +5.43]    13.9  1.2e-40  0.137     --     B better
headroom      Headroom: comp/mean vs best structural (cgcnn/capsule)              9.64  [+8.93, +10.41]    24.8 6.2e-148  0.275     --     B better
backbone                        Backbone: PaiNN vs CGCNN (attention)              6.62   [+5.68, +7.64]    18.2  4.4e-20  0.143     --     B better
backbone                          Backbone: PaiNN vs CGCNN (capsule)              8.52   [+7.57, +9.47]    22.6  6.7e-45  0.186     --     B better
backbone                             Backbone: PaiNN vs CGCNN (mean)              6.33   [+5.37, +7.19]    16.7  1.1e-22  0.141     --     B better
 readout                            Readout: mean vs capsule (cgcnn)              2.39   [+1.82, +2.94]     7.6  1.0e-15  0.089     --     B better
 readout                          Readout: mean vs attention (cgcnn)              1.85   [+1.25, +2.45]     5.9  1.6e-09  0.068     --     B better
 readout                            Readout: mean vs capsule (painn)              0.20   [-0.53, +0.88]     0.5  1.2e-02  0.006     -- inconclusive
 readout                          Readout: mean vs attention (painn)              1.56   [+0.90, +2.22]     4.1  1.7e-08  0.049     --     B better
 readout                      Readout: mean vs capsule (composition)              4.93   [+4.13, +5.73]    12.7  6.0e-38  0.132     --     B better
 readout                    Readout: mean vs attention (composition)             -2.97   [-3.74, -2.22]    -7.6  5.5e-19 -0.081     --     A better

## Residual distribution (formation_energy_per_atom)
        Backbone   Readout  Bias  Median   SD  Skew  Ex. kurt.  |e| p50  |e| p95  |e| p99  |e| max  % |e|>0.1
     CGCNN-style Attention  -1.3    -0.1 42.7 -1.01       22.3     21.6     83.7    134.9    828.9       3.07
     CGCNN-style   Capsule  -0.8     0.7 42.0 -0.75       17.7     20.9     83.8    135.1    751.9       2.86
     CGCNN-style  Mean/max  -1.8    -0.7 45.3 -0.89       19.8     23.0     89.9    146.1    856.7       3.75
Composition-only Attention  -1.8     0.6 59.3 -2.45       61.2     31.9    113.1    177.7   1577.9       7.28
Composition-only   Capsule  -0.0     1.5 52.3 -3.95       87.9     24.3     95.2    159.9   1164.5       4.27
Composition-only  Mean/max  -2.6    -0.7 56.2 -1.54       23.4     28.0    105.1    179.9   1069.2       6.11
  PaiNN-inspired Attention  -2.2    -0.5 60.8 -3.87       64.5     23.2    110.3    199.6   1432.7       6.31
  PaiNN-inspired   Capsule  -2.6    -0.0 63.5 -3.83       66.9     23.7    114.5    216.1   1528.0       6.97
  PaiNN-inspired  Mean/max  -1.4     0.2 61.2 -3.03       40.6     25.3    114.6    208.6   1017.9       6.77

## Error stratification (formation_energy_per_atom) -> T6 tables

## Stale-graph numbers (NOT symmetry tests; reproduces v1 artefact)
transform   basis_change periodic_image permutation reflection  rotation translation
backbone                                                                            
cgcnn           6.79e-01       2.56e+00    2.01e+00   2.38e-07  4.77e-07    1.01e+00
composition     0.00e+00       0.00e+00    2.38e-07   0.00e+00  0.00e+00    0.00e+00
painn           9.58e-01       2.45e+00    1.72e+00   2.62e-06  1.17e-05    1.58e+00

## Symmetry audit, max drift (formation_energy_per_atom)
   backbone   edges precision rotation reflection translation permutation periodic_image basis_change supercell
      cgcnn   fixed      fp32  7.2e-07    4.8e-07     4.8e-07     4.8e-07        4.8e-07      4.8e-07   4.8e-07
      cgcnn   fixed      fp64  1.3e-15    8.9e-16     8.9e-16     8.9e-16        8.9e-16      8.9e-16   8.9e-16
      cgcnn rebuilt      fp32  4.8e-07    4.8e-07     4.8e-07     4.8e-07        4.8e-07      5.7e-04   4.8e-07
      cgcnn rebuilt      fp64  1.3e-15    1.3e-15     8.9e-16     1.3e-15        8.9e-16      5.7e-04   1.3e-15
      cgcnn rebuilt fp64-cap4  1.3e-15    8.9e-16     8.9e-16     8.9e-16        8.9e-16      3.0e-04   1.3e-15
composition   fixed      fp32  0.0e+00    0.0e+00     0.0e+00     4.8e-07        0.0e+00      0.0e+00   6.0e-07
composition   fixed      fp64  0.0e+00    0.0e+00     0.0e+00     8.9e-16        0.0e+00      0.0e+00   8.9e-16
composition rebuilt      fp32  0.0e+00    0.0e+00     0.0e+00     4.8e-07        0.0e+00      0.0e+00   6.0e-07
composition rebuilt      fp64  0.0e+00    0.0e+00     0.0e+00     8.9e-16        0.0e+00      0.0e+00   8.9e-16
      painn   fixed      fp32  1.2e-05    2.6e-06     9.3e-06     1.9e-06        3.3e-05      9.7e-06   3.6e-06
      painn   fixed      fp64  3.1e-14    3.1e-15     3.1e-15     2.2e-15        3.3e-15      3.8e-15   5.3e-15
      painn rebuilt      fp32  1.4e-05    9.5e-07     1.0e-05     1.9e-06        3.4e-05      1.1e-05   3.3e-06
      painn rebuilt      fp64  3.3e-14    2.7e-15     2.7e-15     2.0e-15        3.1e-15      4.9e-15   2.4e-15
      painn rebuilt fp64-cap4  3.3e-14    3.1e-15     4.0e-15     5.3e-15        4.0e-15      7.8e-02   4.9e-15

## Sensitivity: no sens-* runs

## Routing
                   target variant    backbone  H1    H2    H3  M_eff  cap_norm  test_mae  M_eff_sd  cap_norm_sd
formation_energy_per_atom    base       cgcnn 1.0 0.979 0.876  6.421     0.706      29.2       NaN          NaN
formation_energy_per_atom    base composition 1.0 1.000 0.999  7.978     0.187      33.9       NaN          NaN
formation_energy_per_atom    base       painn 1.0 0.990 0.931  7.308     0.646      37.7       NaN          NaN

## Computational cost
                   target    backbone   readout  params  epochs  s_per_epoch  train_h  peak_train_mb  ms_per_struct  peak_infer_mb  graph_ms_per_struct   device
formation_energy_per_atom       cgcnn attention 265,986   199.0         27.0    1.693         2100.0          0.295          181.0               16.608 Tesla T4
formation_energy_per_atom       cgcnn   capsule 270,625   200.0         31.0    1.911         2100.0          0.292          181.0               16.986 Tesla T4
formation_energy_per_atom       cgcnn      mean 266,113   200.0         27.0    1.695         2100.0          0.287          181.0               15.526 Tesla T4
formation_energy_per_atom composition attention  86,402   200.0         10.0    0.646           34.0          0.033           19.0                0.000 Tesla T4
formation_energy_per_atom composition   capsule  91,041   200.0         14.0    0.878           58.0          0.065           23.0                0.000 Tesla T4
formation_energy_per_atom composition      mean  86,529   200.0         10.0    0.668           34.0          0.033           19.0                0.000 Tesla T4
formation_energy_per_atom       painn attention 557,442   200.0         74.0    4.718         5524.0          1.006          611.0               17.800 Tesla T4
formation_energy_per_atom       painn   capsule 562,097   199.0         75.0    4.736         5524.0          0.981          611.0               16.157 Tesla T4
formation_energy_per_atom       painn      mean 557,569   200.0         76.0    4.792         5524.0          0.994          611.0               18.929 Tesla T4

## Descriptor reliance
                   target backbone   readout  mean_abs_change  max_abs_change
formation_energy_per_atom    cgcnn attention         0.069003        0.144168
formation_energy_per_atom    cgcnn   capsule         0.086974        0.194225
formation_energy_per_atom    cgcnn      mean         0.061880        0.178951
formation_energy_per_atom    painn attention         0.047782        0.160987
formation_energy_per_atom    painn   capsule         0.021186        0.086835
formation_energy_per_atom    painn      mean         0.034989        0.075900
