# Expected results

FAIL in *invariance*, *controls*, *routing* or *data* = resolve before using any number. FAIL in *direction* = rewrite the matching `% CHECK` sentence. FAIL in *completeness* = runs still missing. INFO = report the value.

| group | check | expected | observed | status |
|---|---|---|---|---|
| completeness | 3x3 grid trained | 9 cells x 5 seeds | 9 cells, 1-1 seeds | **FAIL** |
| completeness | control cells | 16 | 0 | **MISSING** |
| completeness | band-gap grid | 9 cells x 3 seeds | none | **MISSING** |
| completeness | sensitivity cells | 32 (14 + 18) | 0 | **MISSING** |
| data | split report | data_report/split_summary.csv | absent | **MISSING** |
| invariance | fixed edges, float64, all 7 changes | < 1e-09 | 3.1e-14 | **PASS** |
| invariance | fixed edges, float32, all 7 changes | < 1e-04 | 3.3e-05 | **PASS** |
| invariance | composition-only, every regime | < 1e-06 | 6.0e-07 | **PASS** |
| invariance | rebuilt edges, float32 (corrected pipeline) | < 1e-03 | 5.7e-04 (worst: cgcnn/capsule/basis_change) | **PASS** |
| invariance | rebuilt edges, float64 (complete graph builder) | < 1e-09 | 5.7e-04 | **FAIL** |
| controls | 4-image search cap breaks basis-change invariance (fp64) | > 1e-09 | 7.8e-02 | **PASS** |
| controls | strict top-12 reproduces v1 rebuilt drift | > 1e-03 | - | **MISSING** |
| controls | hard-count descriptors drift more than envelope | hardesc > base | - | **MISSING** |
| controls | normalised-cosine read-back drifts more (fixed rotation) | legacyprobe > base | - | **MISSING** |
| controls | stale graph reproduces v1 translation/permutation artefact | > 0.1 eV/atom | min 0.88 | **PASS** |
| routing | first-iteration coupling entropy H1 (Proposition 1) | 1.0000 | 1.0000-1.0000 | **PASS** |
| accuracy | every model beats the mean predictor (MAD/MAE) | > 10 | min 20.5 | **PASS** |
| accuracy | test MAE (v1 for reference: 31.3-42.0 meV/atom) | same order | 29.2-41.8 meV/atom | **PASS** |
| direction | scalar-vector trails distance-only at every readout | PaiNN > CGCNN (MAE) | +6.6, +8.5, +6.3 meV/atom | **PASS** |
| direction | readout ranking differs between backbones | best readout not identical | cgcnn:capsule, painn:attention, composition:capsule | **PASS** |
| direction | couplings stay close to uniform after 3 iterations | H3 > 0.8 | min H3 0.876 | **PASS** |
